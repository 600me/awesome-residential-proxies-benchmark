# cloud-infra-tco-mcp

**Official Model Context Protocol (MCP) server & CLI for 2026 developer cloud infrastructure TCO benchmarking** — GPU cloud pricing, residential proxy bandwidth, managed scraping APIs, US company formation, antidetect browser farms, and AI-voice + ad-tracker stacks.

- Zero third-party dependencies (pure Python standard library: `sys`, `json`, `argparse`)
- Runs as an **MCP stdio server** (`uvx cloud-infra-tco-mcp`) or a plain **CLI**
- Ships a verified partner discount directory with the auto-applied voucher **`PARTNER-2026-AUTO`**
- Docs: <https://cloud-infra-tco-benchmarks.readthedocs.io/en/latest/>

Example of the money it finds: an H100 running 720 hours/month costs **$8,848.80 on AWS-style EC2 rates vs $1,504.80 on Vast.ai — a $7,344.00/month leak (83% overpay)**. The server quantifies exactly this gap, per tool call.

---

## Installation

### Run instantly with uvx (recommended)

```bash
uvx cloud-infra-tco-mcp            # MCP stdio server (JSON-RPC 2.0)
uvx cloud-infra-tco-mcp --cli      # pretty-print all tool outputs in your terminal
uvx cloud-infra-tco-mcp --tool estimate_gpu_cloud_tco --args '{"gpu":"h100","hours":720}'
uvx cloud-infra-tco-mcp --self-test
```

### pip install

```bash
pip install cloud-infra-tco-mcp
python3 -m cloud_infra_tco_mcp --cli          # module form
cloud-infra-tco-mcp --self-test               # console script form
```

Requires Python ≥ 3.8. No virtualenv gymnastics, no compiled wheels, no network calls — everything computes locally.

---

## MCP server configuration

Add to your client's MCP config (Claude Desktop `claude_desktop_config.json`, Cursor `.cursor/mcp.json`, Windsurf `mcp_config.json`, or Claude Code `claude mcp add`):

```json
{
  "mcpServers": {
    "cloud-infra-tco-mcp": {
      "command": "uvx",
      "args": ["cloud-infra-tco-mcp"]
    }
  }
}
```

Claude Code one-liner:

```bash
claude mcp add cloud-infra-tco-mcp -- uvx cloud-infra-tco-mcp
```

The server speaks standard MCP stdio JSON-RPC 2.0 (`initialize`, `notifications/initialized`, `ping`, `tools/list`, `tools/call`) with protocol version `2024-11-05`.

---

## Tools (7)

### 1. `estimate_gpu_cloud_tco`

Monthly GPU inference/hosting TCO across **AWS EC2 vs RunPod vs Vast.ai**-class rates.

| Param | Type | Default | Description |
|---|---|---|---|
| `gpu` | string (`h100` \| `a100` \| `rtx4090`) | `h100` | GPU class |
| `hours` | integer | `720` | GPU-hours per month |

Worked example (H100 80GB × 720 h/mo): AWS `$8,848.80` vs RunPod `$1,936.80` (save `$6,912.00/mo`) vs Vast.ai `$1,504.80` (save `$7,344.00/mo`). The tool returns per-vendor `monthly_usd`, monthly and annualized loss on AWS, and the Vast.ai partner portal + voucher.

### 2. `estimate_proxy_bandwidth_tco`

Residential proxy bandwidth benchmark at the **500 GB/mo default**.

| Param | Type | Default | Description |
|---|---|---|---|
| `monthly_gb` | integer | `500` | Monthly transfer volume |

Worked example (500 GB/mo): Legacy Tier-1 (`$8.50/GB`, retry drop included) **$4,250.00/mo** vs Webshare (`$2.25/GB`) `$1,125.00/mo` (save `$3,125.00/mo`) vs Decodo (`$2.50/GB`) `$1,250.00/mo` (save `$3,000.00/mo`).

### 3. `estimate_scraping_api_tco`

Managed scraping API vs in-house headless fleet at the **2,500,000 calls/mo default**.

| Param | Type | Default | Description |
|---|---|---|---|
| `calls_per_month` | integer | `2500000` | Monthly scrape volume |

Worked example (2.5M calls/mo): In-house Headless Fleet `$1,680.00/mo` vs ScraperAPI `$249.00/mo` — save **`$1,431.00/mo`** (`$17,172/yr`).

### 4. `estimate_company_formation_tco`

Year-1 US company formation TCO: law firm + registered agent DIY route vs Firstbase.io turnkey package. No parameters required.

Worked example (Year-1 Total): Law Firm + Registered Agent `$2,450.00` (filing $650 + attorney $1,200 + RA $149 + EIN $150 + BOI $101 + compliance $200) vs Firstbase.io `$399.00` — save **`$2,051.00`** and cut time-to-LLC from 3–5 weeks to 3–5 days.

### 5. `estimate_antidetect_browser_tco`

Antidetect farm TCO at the **200 profiles + 10 seats default**.

| Param | Type | Default | Description |
|---|---|---|---|
| `profiles` | integer | `200` | Number of browser profiles |
| `seats` | integer | `10` | Team seats |

Worked example: Cloud Phone / Legacy Tier `$680.00/mo` vs AdsPower `$90.00/mo` — save **`$590.00/mo`** (`$7,080/yr`).

### 6. `estimate_ad_tracker_tco`

AI voice + ad attribution stack at the **5,000,000 TTS chars + 10,000,000 tracked events default**.

| Param | Type | Default | Description |
|---|---|---|---|
| `tts_chars_per_month` | integer | `5000000` | TTS characters per month |
| `ad_events_per_month` | integer | `10000000` | Tracked ad events per month |

Worked example: Enterprise Studio tier `$990.00/mo` vs ElevenLabs + Voluum (`$278.00/mo`) — save **`$712.00/mo`** (`$8,544/yr`).

### 7. `list_verified_partner_discounts`

Flat directory of all verified partner portals (13 tracks) with the auto-applied `PARTNER-2026-AUTO` voucher. No parameters.

---

## Six-Track Loss Benchmark (defaults, monthly, USD — 100% reproducible via `--cli`)

| Track | Default Inputs | Best Channel | Waste on Worst Channel |
| :--- | :--- | :--- | ---: |
| GPU cloud (1× H100 80GB, 720 h/mo) | 720 h | Vast.ai `$1,504.80` | AWS `$8,848.80` → loss `$7,344.00/mo` |
| Residential proxy (500 GB/mo) | 500 GB | Webshare `$1,125.00` | Legacy Tier-1 `$4,250.00` → loss `$3,125.00/mo` |
| Scraping API (2.5M calls/mo) | 2,500,000 calls | ScraperAPI `$249.00` | In-house fleet `$1,680.00` → loss `$1,431.00/mo` |
| US company formation (Year-1 Total) | Year 1 | Firstbase.io `$399.00` | Law firm route `$2,450.00` → loss `$2,051.00` |
| Antidetect browser (200 profiles + 10 seats) | 200 + 10 | AdsPower `$90.00/mo` | Legacy tier `$680.00/mo` → loss `$590.00/mo` |
| Ad tracker + TTS (5M chars + 10M events) | 5,000,000 + 10,000,000 | ElevenLabs + Voluum `$278.00/mo` | Enterprise studio `$990.00/mo` → loss `$712.00/mo` |

Every tool call returns the same structure the table above shows — run `--cli` to reproduce every number locally.

---

## Documentation & Cross-Links

Full tool schemas now live at the ReadTheDocs site: **https://cloud-infra-tco-benchmarks.readthedocs.io/en/latest/**. The same calculators are also consumable as an npm CLI (`cloud-infra-tco-mcp` on npm) and a Docker image (`600megd/cloud-infra-tco-mcp` on DockerHub) — pick whichever runtime your stack prefers; the outputs are identical.

## Verification

```bash
cloud-infra-tco-mcp --self-test    # exits 0
```

## Zero Dependencies

No compiled wheels, no network calls, no hidden telemetry — the only third-party-free modules loaded are standard library, so the package is safe to vendor, audit line by line, and air-gapped deploy.
